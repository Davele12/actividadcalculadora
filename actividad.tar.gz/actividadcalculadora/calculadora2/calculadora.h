/*
 * * FILE: calculadora.h
 * * juncotic.com
 * */

#ifndef CALCULADORA_H

#define CALCULADORA_H
#include<stdio.h>
#include<stdlib.h>
int suma(int,int);
int resta(int,int);

#endif
