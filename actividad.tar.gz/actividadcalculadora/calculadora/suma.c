/*
 * * FILE: suma.c
 * * juncotic.com
 * */

int suma(int n1, int n2){
	    return n1+n2;
}
