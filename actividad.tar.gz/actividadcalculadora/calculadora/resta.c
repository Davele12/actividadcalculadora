/*
 * * FILE: resta.c
 * * juncotic.com
 * */

int resta(int n1, int n2){
	    return n1-n2;
}

